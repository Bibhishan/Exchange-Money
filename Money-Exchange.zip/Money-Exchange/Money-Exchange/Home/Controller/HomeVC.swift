//
//  ViewController.swift
//  Money-Exchange
//
//  Created by Abcom on 07/12/24.
//

import UIKit

class HomeVC: UIViewController, UIViewControllerTransitioningDelegate, UIPopoverPresentationControllerDelegate{
    
    @IBOutlet weak var countryTF: UITextField!
    @IBOutlet weak var deliveryMethodTF: UITextField!
    @IBOutlet weak var flagImageBtn: UIButton!
    @IBOutlet weak var currencyBtn: UIButton!
    @IBOutlet weak var currentCurrencyLbl: UILabel!
    @IBOutlet weak var depositTF: UITextField!
    @IBOutlet weak var receiptantTF: UITextField!
    
    private var viewModel = CurrencyExchangeViewModel()
    private var currencyData: CurrencyData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = StringConstant.moneyTransfer.rawValue
        depositTF.textAlignment = .right
        receiptantTF.textAlignment = .right
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.fetchCurrencyExchangeRate()
        depositTF.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField){
        if let val = currencyData?.exchangeRate, let doubleVal = Double(val){
            let depositVal = Double(textField.text ?? "") ?? 0
            receiptantTF.text = "\(depositVal * doubleVal)"
        }
    }
    
    @IBAction func selectCountry(_ sender: UIButton){
        presentSheetViewController(
            withIdentifier: UIViewControllerString.countrySelect.rawValue,
            delegate: self,
            detents: [.medium(), .large()]
        )
    }
    
    @IBAction func deliveryMethodBtn(_ sender: UIButton){
        presentSheetViewController(
            withIdentifier: UIViewControllerString.deliveryMethod.rawValue,
            delegate: self,
            detents: [.medium()]
        )
    }
    
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        return HalfSizePresentationController(presentedViewController: presented, presenting: presentingViewController)
    }
}
extension HomeVC: PassCountryDelegate, DeliveryMethodDelegate {
    func didSelectDeliveryMethod(_ deliveryMethod: DeliveryMethodModel) {
        deliveryMethodTF.text = deliveryMethod.name
    }
    
    func passCountry(_ country: CountryDataModel) {
        countryTF.text = country.name.common
        if let data = viewModel.fetchCurrencyExchangeData(country.cioc){
            self.currencyData = data
            flagImageBtn.kf.setImage(with: URL(string: country.flags.png), for: .normal)
            currencyBtn.setTitle(country.cca2, for: .normal)
            currentCurrencyLbl.text = "1 AED = \(data.exchangeRate) \(data.currencypair)"
        }
    }
}

extension HomeVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
