//
//  ExchangeData.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import Foundation

// Define the models for the JSON structure
struct CurrencyExchangeResponse: Decodable {
    let result: CurrencyResult
}

struct CurrencyResult: Decodable {
    let depositCountry: String
    let depositCurrency: String
    let depositCountryCode: String
    let data: [CurrencyData]
    let responseStatus: String
    let responseMessage: String
}

struct CurrencyData: Decodable {
    let currencypair: String
    let countryCode: String
    let exchangeRate: String
}

