//
//  Exchange_Data.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import Foundation

// Example JSON structure
let jsonString = """
{
    "result": {
        "depositCountry": "United Arab Emirates",
        "depositCurrency": "AED",
        "depositCountryCode": "UAE",
        "data": [
            {
                "currencypair": "AUD",
                "countryCode": "AUS",
                "exchangeRate": "0.40"
            },
            {
                "currencypair": "JPY",
                "countryCode": "JPN",
                "exchangeRate": "42.75"
            },
            {
                "currencypair": "CAD",
                "countryCode": "CAN",
                "exchangeRate": "0.37"
            },
            {
                "currencypair": "SGD",
                "countryCode": "SGP",
                "exchangeRate": "0.37"
            },
            {
                "currencypair": "GBP",
                "countryCode": "GBR",
                "exchangeRate": "0.21"
            },
            {
                "currencypair": "EUR",
                "countryCode": "FRA",
                "exchangeRate": "0.25"
            },
            {
                "currencypair": "USD",
                "countryCode": "USA",
                "exchangeRate": "0.27"
            },
            {
                "currencypair": "INR",
                "countryCode": "IND",
                "exchangeRate": "22.75"
            },
            {
                "currencypair": "PKR",
                "countryCode": "PAK",
                "exchangeRate": "75.85"
            },
            {
                "currencypair": "PHP",
                "countryCode": "PHI",
                "exchangeRate": "15.87"
            },
            {
                "currencypair": "NPR",
                "countryCode": "NEP",
                "exchangeRate": "36.40"
            },
            {
                "currencypair": "LKR",
                "countryCode": "SRI",
                "exchangeRate": "82.62"
            },
            {
                "currencypair": "AFN",
                "countryCode": "AFG",
                "exchangeRate": "19.23"
            },
            {
                "currencypair": "ALL",
                "countryCode": "ALB",
                "exchangeRate": "25.07"
            }
        ],
        "timestamp": "null",
        "errorCode": "null",
        "responseStatus": "success",
        "responseMessage": "Workflow run was completed successfully.",
        "reason": null
    }
}
"""

class CurrencyExchangeViewModel {
    var currency: [CurrencyData] = []
    // Convert JSON string to Data
    func fetchCurrencyExchangeRate() {
        if let jsonData = jsonString.data(using: .utf8) {
            do {
                // Decode the JSON into the CurrencyExchangeResponse model
                let decodedResponse = try JSONDecoder().decode(CurrencyExchangeResponse.self, from: jsonData)
                DispatchQueue.main.async {
                    self.currency = decodedResponse.result.data
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }
    }
    
    func fetchCurrencyExchangeData(_ countryCode: String) -> CurrencyData? {
        let data = currency.filter{ $0.countryCode == countryCode }
        return data.first ?? nil
    }
}
