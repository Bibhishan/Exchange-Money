//
//  Extension+UIViewController.swift
//  Money-Exchange
//
//  Created by Abcom on 09/12/24.
//

import UIKit

extension UIViewController {
    
    /// Presents a view controller in a sheet format with navigation and detents
    func presentSheetViewController(
        withIdentifier identifier: String,
        delegate: AnyObject? = nil,
        detents: [UISheetPresentationController.Detent] = [.medium(), .large()],
        hidesNavigationBar: Bool = true,
        animated: Bool = true,
        completion: (() -> Void)? = nil
    ) {
        // Instantiate the view controller
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: identifier) {
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .pageSheet
            
            // Set the delegate if applicable
            if let delegate = delegate {
                if let vcWithDelegate = vc as? CountrySelectVC {
                    vcWithDelegate.delegate = delegate as? PassCountryDelegate
                } else if let vcWithDelegate = vc as? DeliveryMethodVC {
                    vcWithDelegate.delegate = delegate as? DeliveryMethodDelegate
                }
            }
            
            // Hide the navigation bar if needed
            vc.navigationController?.navigationBar.isHidden = hidesNavigationBar
            
            // Set sheet presentation for iOS 15 and above
            if #available(iOS 15.0, *) {
                if let sheet = nav.sheetPresentationController {
                    sheet.detents = detents
                }
            }
            
            // Present the view controller
            self.present(nav, animated: animated, completion: completion)
        }
    }
}
