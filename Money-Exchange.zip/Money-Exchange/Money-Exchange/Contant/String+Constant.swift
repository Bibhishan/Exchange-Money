//
//  String+Constant.swift
//  Money-Exchange
//
//  Created by Abcom on 09/12/24.
//

import Foundation

enum StringConstant: String {
    case moneyTransfer = "Money transfer"
}

enum UIViewControllerString: String {
    case countrySelect = "CountrySelectVC"
    case deliveryMethod = "DeliveryMethodVC"
}

enum CellIdentifier: String {
    case countryCell = "CountryListCell"
}

enum APIString: String {
    case currencyAPI = "https://restcountries.com/v3.1/independent?fields=name,languages,capital,flags,currencies,cca2,cioc"
}
