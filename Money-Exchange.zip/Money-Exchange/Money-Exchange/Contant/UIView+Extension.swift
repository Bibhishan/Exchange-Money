//
//  UIView+Extension.swift
//  Money-Exchange
//
//  Created by Abcom on 09/12/24.
//

import UIKit

@IBDesignable
class CustomView: UIView {
    
    // Inspectable property for corner radius
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
        }
    }
    
    // Inspectable property for border width
    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            self.layer.borderWidth = borderWidth
        }
    }
    
    // Inspectable property for border color
    @IBInspectable var borderColor: UIColor = UIColor.clear {
        didSet {
            self.layer.borderColor = borderColor.cgColor
        }
    }

    // Inspectable property for background color (optional, as UIView already has a backgroundColor property)
    @IBInspectable var customBackgroundColor: UIColor = UIColor.white {
        didSet {
            self.backgroundColor = customBackgroundColor
        }
    }
    
    // Override init methods
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    // Method to apply initial view setup
    private func setupView() {
        self.layer.masksToBounds = true
    }
}

