//
//  DeliveryMethodVC.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import UIKit

protocol DeliveryMethodDelegate: AnyObject {
    func didSelectDeliveryMethod(_ deliveryMethod: DeliveryMethodModel)
}

class DeliveryMethodVC: UIViewController {
    
    @IBOutlet weak var bankBtn: UIButton!
    @IBOutlet weak var cashBtn: UIButton!
    @IBOutlet weak var mobileBtn: UIButton!
    
    var deliveryMethod: [DeliveryMethodModel] = []
    weak var delegate: DeliveryMethodDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupData()
    }
    
    private func setupData() {
        deliveryMethod = [DeliveryMethodModel(name: "Bank Account", logo: "indianrupeesign.bank.building"),
                          DeliveryMethodModel(name: "Cash Pickup", logo: "dollarsign.square"),
                          DeliveryMethodModel(name: "Mobile wallet", logo: "wallet.bifold")
        ]
    }
    
    @IBAction func selectDeliveryMethod(_ sender: UIButton) {
        delegate?.didSelectDeliveryMethod(deliveryMethod[sender.tag])
        self.dismiss(animated: true)
    }
    
}
