//
//  HalfSizePresentationController.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import UIKit

class HalfSizePresentationController: UIPresentationController {
    
    // The height for the presented view
    override var frameOfPresentedViewInContainerView: CGRect {
        guard let containerView = containerView else { return CGRect.zero }
        
        // Determine the size and position for the presented view controller (half the screen height)
        let height: CGFloat = containerView.bounds.height / 2
        let originY: CGFloat = containerView.bounds.height - height
        return CGRect(x: 0, y: originY, width: containerView.bounds.width, height: height)
    }
    
    // Optional: Add a dimming view behind the modal
    override func presentationTransitionWillBegin() {
        guard let containerView = containerView else { return }
        
        // Add a dimming view to darken the background when the modal appears
        let dimmingView = UIView(frame: containerView.bounds)
        dimmingView.backgroundColor = UIColor(white: 0.0, alpha: 0.5)
        dimmingView.alpha = 0
        
        containerView.addSubview(dimmingView)
        
        presentedViewController.transitionCoordinator?.animate(alongsideTransition: { _ in
            dimmingView.alpha = 1
        }, completion: nil)
    }
    
    override func dismissalTransitionWillBegin() {
        // Fade out the dimming view when the modal is dismissed
        containerView?.subviews.last?.alpha = 1
        presentedViewController.transitionCoordinator?.animate(alongsideTransition: { _ in
            self.containerView?.subviews.last?.alpha = 0
        }, completion: { _ in
            self.containerView?.subviews.last?.removeFromSuperview()
        })
    }
}

