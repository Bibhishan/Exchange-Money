//
//  CountrySelectVC.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import UIKit
import Combine

protocol PassCountryDelegate: AnyObject {
    func passCountry(_ country: CountryDataModel)
}

class CountrySelectVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchCountryTF: UITextField!
    weak var delegate: PassCountryDelegate?
    
    var countryViewModel = CountryViewModel()
        
    // Store cancellables for Combine
    var cancellables: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bindViewModel()
        searchCountryTF.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        tableView.register(UINib(nibName: CellIdentifier.countryCell.rawValue, bundle: nil), forCellReuseIdentifier: CellIdentifier.countryCell.rawValue)
        // Fetch data using async/await
        Task {
            await countryViewModel.fetchUsers()
        }
    }
    
    func bindViewModel() {
        countryViewModel.$searchCountries
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.tableView.reloadData()
            }
            .store(in: &cancellables)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField){
        if let searchText = textField.text, !searchText.isEmpty {
            countryViewModel.searchCountries = countryViewModel.countries.filter { item in
                item.name.common.localizedCaseInsensitiveContains(searchText)
            }
        } else {
            countryViewModel.searchCountries = countryViewModel.countries
        }
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
}
extension CountrySelectVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countryViewModel.searchCountries.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.countryCell.rawValue, for: indexPath) as? CountryListCell{
            let user = countryViewModel.searchCountries[indexPath.row]
            cell.setupData(data: user)
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let country = countryViewModel.searchCountries[indexPath.row]
        delegate?.passCountry(country)
        dismiss(animated: true, completion: nil)
    }
}

extension CountrySelectVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
