//
//  CountryDataModel.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import UIKit

struct CountryDataModel: Codable {
    struct Flag: Codable {
        let png: String
        let svg: String
        let alt: String
    }
    
    struct Currency: Codable {
        let name: String
        let symbol: String
    }
    
    struct Name: Codable {
        let common: String
        let official: String
    }
    
    let flags: Flag
    let name: Name
    let cca2: String
    let cioc: String
    let capital: [String]
    let currencies: [String: Currency]
}

struct DeliveryMethodModel {
    let name: String
    let logo: String
}
