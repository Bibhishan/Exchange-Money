//
//  CountryViewModel.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import Foundation

let session = URLSession(configuration: .default, delegate: CustomSessionDelegate(), delegateQueue: nil)

class CountryViewModel {
    // Published property to store users
    @Published var countries: [CountryDataModel] = []
    @Published var searchCountries: [CountryDataModel] = []
    
    // API Call using async/await
    func fetchUsers() async {
        let urlString = APIString.currencyAPI.rawValue
        guard let url = URL(string: urlString) else { return }
        
        do {
            
            let (data, _) = try await session.data(from: url)
            let countries = try JSONDecoder().decode([CountryDataModel].self, from: data)
                        
            DispatchQueue.main.async {
                self.countries = countries
                self.searchCountries = countries
            }
        } catch {
            print("Failed to fetch users: \(error)")
        }
    }
}

class CustomSessionDelegate: NSObject, URLSessionDelegate {
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if let serverTrust = challenge.protectionSpace.serverTrust {
            let credential = URLCredential(trust: serverTrust)
            completionHandler(.useCredential, credential)
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}
