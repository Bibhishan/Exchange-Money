//
//  CountryListCell.swift
//  Money-Exchange
//
//  Created by Abcom on 08/12/24.
//

import UIKit
import Kingfisher

class CountryListCell: UITableViewCell {
    
    @IBOutlet weak var flagImage: UIImageView!
    @IBOutlet weak var countryName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setupData(data: CountryDataModel){
        let downloader = KingfisherManager.shared.downloader
        downloader.trustedHosts = Set(["flagcdn.com"])
        flagImage.kf.setImage(with: URL(string: data.flags.png))
        countryName.text = data.name.common
    }
    
}
